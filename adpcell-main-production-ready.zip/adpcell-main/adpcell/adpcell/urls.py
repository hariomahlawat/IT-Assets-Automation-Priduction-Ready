from django.contrib import admin
from django.urls import path, include

admin.site.site_header = 'ADP Cell Admin Panel'
admin.site.site_title = 'ADP Cell'
admin.site.index_title = "Welcome to ADP Cell Portal"

urlpatterns = [
    # Django admin
    path('admin/', admin.site.urls),

    # User management
    path('accounts/', include('django.contrib.auth.urls')),  # new

    #Local apps
    path('inventory/', include('inventory.urls', namespace='inventory')),
    path('vc/', include('vc.urls', namespace='vc')),
    path('project/', include('project.urls', namespace='project')),
    path('accounts/', include('users.urls', namespace='users')),
]
