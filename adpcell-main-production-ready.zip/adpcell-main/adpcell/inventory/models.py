# inventory/models.py
import uuid
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse


# Create your models here.
class ITAsset(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name

class Section(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name        
'''
-------------------------------------------------------------------------------------------------------------------------------
Models for Desktop Inventory
'''
class DesktopListManager(models.Manager):
    def get_queryset(self):
        return super(DesktopListManager,self).get_queryset()


class Desktop(models.Model):
    objects = models.Manager() # The default manager.
    desktop_list = DesktopListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_desktops')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_desktops')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    desktop_model = models.CharField(max_length=50, null=True, blank=True)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)
    mac_address = models.CharField( max_length=50, null=True, blank=True)
    cpu = models.CharField( max_length=50, null=True, blank=True)
    ram_gb = models.CharField( max_length=50, null=True, blank=True)
    ram_clock_speed = models.IntegerField(null=True, blank=True)
    ram_type = models.CharField( max_length=50, null=True, blank=True)
    disk_details = models.CharField( max_length=100, null=True, blank=True)
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('desktop_detail', args=[str(self.id)])  

class DesktopSoftwareManager(models.Manager):
    def get_queryset(self):
        return super(DesktopSoftwareManager,self).get_queryset()

class DesktopSoftware(models.Model):
    objects = models.Manager() # The default manager.
    desktop_sofwtare_list = DesktopListManager() # Our custom manager.

    desktop_id = models.ForeignKey("inventory.Desktop", on_delete=models.CASCADE, related_name='software_details')
    date_collected = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)
    os = models.CharField(null=True, blank=True, max_length=50)
    os_version = models.CharField(null=True, blank=True, max_length=50)
    os_build_no = models.CharField(null=True, blank=True, max_length=50)
    os_installation_date = models.DateField(null=True, blank=True, auto_now=False, auto_now_add=False)    
    os_product_serNo = models.CharField(null=True, blank=True, max_length=50)
    os_latest_hotfix = models.CharField(null=True, blank=True, max_length=50)
    os_architecture = models.CharField(null=True, blank=True, max_length=50)
    description = models.TextField( max_length=2000, null=True, blank=True)

    def __str__(self):
        return self.os   

    def get_absolute_url(self):
        return reverse('desktop_software_detail', args=[str(self.desktop_id)])                

'''
---------------------------------------------------------------------------------------------------------------------------------
Models for Laptop Inventory
'''

class LaptopListManager(models.Manager):
    def get_queryset(self):
        return super(LaptopListManager,self).get_queryset()


class Laptop(models.Model):
    objects = models.Manager() # The default manager.
    laptop_list = LaptopListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_laptops')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_laptops')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    laptop_model = models.CharField(max_length=50, null=True, blank=True)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)
    mac_address = models.CharField( max_length=50, null=True, blank=True)
    cpu = models.CharField( max_length=50, null=True, blank=True)
    ram_gb = models.CharField( max_length=50, null=True, blank=True)
    ram_clock_speed = models.IntegerField(null=True, blank=True)
    ram_type = models.CharField( max_length=50, null=True, blank=True)
    disk_details = models.CharField( max_length=100, null=True, blank=True)
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('laptop_detail', args=[str(self.id)])  

class LaptopSoftwareManager(models.Manager):
    def get_queryset(self):
        return super(LaptopSoftwareManager,self).get_queryset()

class LaptopSoftware(models.Model):
    objects = models.Manager() # The default manager.
    laptop_sofwtare_list = LaptopListManager() # Our custom manager.

    laptop_id = models.ForeignKey("inventory.Laptop", on_delete=models.CASCADE, related_name='laptop_software_details')
    date_collected = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)
    os = models.CharField(null=True, blank=True, max_length=50)
    os_version = models.CharField(null=True, blank=True, max_length=50)
    os_build_no = models.CharField(null=True, blank=True, max_length=50)
    os_installation_date = models.DateField(null=True, blank=True, auto_now=False, auto_now_add=False)    
    os_product_serNo = models.CharField(null=True, blank=True, max_length=50)
    os_latest_hotfix = models.CharField(null=True, blank=True, max_length=50)
    os_architecture = models.CharField(null=True, blank=True, max_length=50)
    description = models.TextField( max_length=2000, null=True, blank=True)
    

    def __str__(self):
        return self.os   

    def get_absolute_url(self):
        return reverse('laptop_software_detail', args=[str(self.laptop_id)])  

'''
---------------------------------------------------------------------------------------------------------------------------------
Models for Printer Inventory
'''

class PrinterListManager(models.Manager):
    def get_queryset(self):
        return super(PrinterListManager,self).get_queryset()


class Printer(models.Model):
    objects = models.Manager() # The default manager.
    printer_list = PrinterListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    PRINTING_TECH_CHOICES = (
        ('laserjet', 'Laserjet'),
        ('inkjet', 'Inkjet'),
        ) 
    COLOR_OUTPUT_CHOICES = (
        ('monochrome', 'Monochrome'),
        ('color', 'Color'),
        )       
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_printers')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_printers')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    model_no = models.CharField(max_length=50, null=True, blank=True)
    color_output = models.CharField( max_length=50, choices=COLOR_OUTPUT_CHOICES, default= 'monochrome', null=True, blank=True)
    printing_tech = models.CharField( max_length=50, choices=PRINTING_TECH_CHOICES, default='laserjet', null=True, blank=True)
    print_speed = models.IntegerField(null=True, blank=True)
    scan_functionality = models.BooleanField(default=False)
    copy_functionality = models.BooleanField(default=False)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)
    fsma = models.BooleanField(default=False)
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('printer_detail', args=[str(self.id)])  

'''
---------------------------------------------------------------------------------------------------------------------------------
Models for NAS Inventory
'''

class NASListManager(models.Manager):
    def get_queryset(self):
        return super(NASListManager,self).get_queryset()


class NAS(models.Model):
    objects = models.Manager() # The default manager.
    nas_list = PrinterListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
      
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_nas')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_nas')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    model_no = models.CharField(max_length=50, null=True, blank=True)
  
    storage_capacity_tb = models.IntegerField(null=True, blank=True)
    no_of_hard_disks = models.IntegerField(null=True, blank=True)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('nas_detail', args=[str(self.id)])  


'''
-------------------------------------------------------------------------------------------------------------------------------
Models for Rack Server Inventory
'''
class RackServerListManager(models.Manager):
    def get_queryset(self):
        return super(RackServerListManager,self).get_queryset()


class RackServer(models.Model):
    objects = models.Manager() # The default manager.
    rack_server_list = RackServerListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_rack_servers')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_rack_servers')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    model = models.CharField(max_length=50, null=True, blank=True)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)

    no_of_cpus = models.IntegerField(null=True, blank=True)
    cpu_details = models.TextField( max_length=1000, null=True, blank=True)
    storage_details = models.TextField( max_length=1000, null=True, blank=True)
    memory_details = models.TextField( max_length=1000, null=True, blank=True)
  
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('rack_server_detail', args=[str(self.id)])  



'''
-------------------------------------------------------------------------------------------------------------------------------
Models for Blade Server Inventory
'''
class BladeServerListManager(models.Manager):
    def get_queryset(self):
        return super(BladeServerListManager,self).get_queryset()


class BladeServer(models.Model):
    objects = models.Manager() # The default manager.
    blade_server_list = BladeServerListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_blade_servers')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_blade_servers')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    model = models.CharField(max_length=50, null=True, blank=True)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)

    no_of_blades = models.IntegerField(null=True, blank=True)
    no_of_cpus = models.IntegerField(null=True, blank=True)
    cpu_details = models.TextField( max_length=1000, null=True, blank=True)
    storage_details = models.TextField( max_length=1000, null=True, blank=True)
    memory_details = models.TextField( max_length=1000, null=True, blank=True)
  
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('blade_server_detail', args=[str(self.id)])  


'''
-------------------------------------------------------------------------------------------------------------------------------
Models for SAN Storage Inventory
'''
class SANListManager(models.Manager):
    def get_queryset(self):
        return super(SANListManager,self).get_queryset()


class SAN(models.Model):
    objects = models.Manager() # The default manager.
    san_list = SANListManager() # Our custom manager.
    id = models.UUIDField( # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    asset_id = models.ForeignKey("inventory.ITAsset", on_delete=models.CASCADE, related_name='all_sans')
    section_id = models.ForeignKey("inventory.Section", on_delete=models.CASCADE,related_name='section_sans')
    serNo = models.CharField(max_length=50, unique=True, null=False, blank=False)
    make = models.CharField(max_length=50, null=True, blank=True)
    model = models.CharField(max_length=50, null=True, blank=True)
    purchase_date = models.DateField( auto_now=False, auto_now_add=False, null=True, blank=True)

    storage_capacity = models.IntegerField(null=True, blank=True)
    no_of_drive_slots_available = models.IntegerField(null=True, blank=True)
    no_of_controllers = models.IntegerField(null=True, blank=True)
  
    description = models.TextField( max_length=2000, null=True, blank=True)
 
    class Meta:
        ordering = ('purchase_date',)

    def __str__(self):
        return self.serNo 

    def get_absolute_url(self):
        return reverse('san_detail', args=[str(self.id)])