from django.urls import path
from .views import *

app_name = 'inventory'

urlpatterns = [
    # Desktop views
    path('desktop/', DesktopListView.as_view(), name='desktop_list'),
    path('<uuid:pk>/', DesktopDetailView.as_view(),  name='desktop_detail'),
    # Laptop views
    path('laptop/', LaptopListView.as_view(), name='laptop_list'),
    path('laptop/<uuid:pk>/', LaptopDetailView.as_view(),  name='laptop_detail'),
    # Printer views
    path('printer/', PrinterListView.as_view(), name='printer_list'),
    path('printer/<uuid:pk>/', PrinterDetailView.as_view(),  name='printer_detail'),
    # NAS views
    path('nas/', NASListView.as_view(), name='nas_list'),
    path('nas/<uuid:pk>/', NASDetailView.as_view(),  name='nas_detail'),
    # SAN views
    path('san/', SANListView.as_view(), name='san_list'),
    path('san/<uuid:pk>/', SANDetailView.as_view(),  name='san_detail'),
    # Rack Server views
    path('rack_server/', RackServerListView.as_view(), name='rack_server_list'),
    path('rack_server/<uuid:pk>/', RackServerDetailView.as_view(),  name='rack_server_detail'),
    # Blade Server views
    path('blade_server/', BladeServerListView.as_view(), name='blade_server_list'),
    path('blade_server/<uuid:pk>/', BladeServerDetailView.as_view(),  name='blade_server_detail'),
    #Dashboard
    path('dashboard/', DashboardView.as_view(), name='dashboard'),  

    #--------------------------- Section View ----------------------- 
    path('section/mo01/', Mo1Inventory.as_view(), name='mo1_inventory'),
    path('section/mo02/', Mo2Inventory.as_view(), name='mo2_inventory'),
    path('section/mo3a/', Mo3AInventory.as_view(), name='mo3a_inventory'),
    path('section/mo3b/', Mo3BInventory.as_view(), name='mo3b_inventory'),
    path('section/mo4/', Mo4Inventory.as_view(), name='mo4_inventory'),
    path('section/mo5/', Mo5Inventory.as_view(), name='mo5_inventory'),
    path('section/mo6/', Mo6Inventory.as_view(), name='mo6_inventory'),
    path('section/mo7/', Mo7Inventory.as_view(), name='mo7_inventory'),
    path('section/mo8a/', Mo8AInventory.as_view(), name='mo8a_inventory'),
    path('section/mo8b/', Mo8BInventory.as_view(), name='mo8b_inventory'),
    path('section/mo9/', Mo9Inventory.as_view(), name='mo9_inventory'),
    path('section/mo10/', Mo10Inventory.as_view(), name='mo10_inventory'),
    path('section/mo11/', Mo11Inventory.as_view(), name='mo11_inventory'),
    path('section/mo12/', Mo12Inventory.as_view(), name='mo12_inventory'),
    path('section/server_room/', ServerRoomInventory.as_view(), name='server_room_inventory'),
    path('section/adp_cell/', ADPCellInventory.as_view(), name='adp_cell_inventory'),
    path('section/adp_store/', ADPStoreInventory.as_view(), name='adp_store_inventory'),
]
