from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(ITAsset)
admin.site.register(Section)

#-------- Desktop Models-----------------------------------------------------------
@admin.register(Desktop)
class DesktopAdmin(admin.ModelAdmin):
    list_display = ('id', 'asset_id', 'section_id', 'serNo', 'purchase_date','cpu','ram_gb')
    list_filter = ( 'purchase_date','section_id', 'ram_gb')
    search_fields = ('serNo', 'cpu','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date')


@admin.register(DesktopSoftware)
class DesktopSoftwareAdmin(admin.ModelAdmin):
    list_display=('pk','desktop_id','os','os_version','os_latest_hotfix','os_architecture','date_collected')
    list_filter = ( 'os','os_installation_date', 'os_latest_hotfix')

#-------- Laptop Models-----------------------------------------------------------
@admin.register(Laptop)
class LaptopAdmin(admin.ModelAdmin):
    list_display = ('id', 'asset_id', 'section_id', 'serNo', 'purchase_date','cpu','ram_gb')
    list_filter = ( 'purchase_date','section_id', 'ram_gb')
    search_fields = ('serNo', 'cpu','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date')


@admin.register(LaptopSoftware)
class LaptopSoftwareAdmin(admin.ModelAdmin):
    list_display=('pk','laptop_id','os','os_version','os_latest_hotfix','os_architecture','date_collected')
    list_filter = ( 'os','os_installation_date', 'os_latest_hotfix')

#-------- Printer-----------------------------------------------------------
@admin.register(Printer)
class PrinterAdmin(admin.ModelAdmin):
    list_display = ('serNo','make', 'model', 'section_id', 'color_output','printing_tech','fsma', 'purchase_date')
    list_filter = ( 'purchase_date','section_id', 'color_output','fsma','scan_functionality','copy_functionality')
    search_fields = ('serNo', 'make','model','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date')   

#-------- NAS-----------------------------------------------------------
@admin.register(NAS)
class NASAdmin(admin.ModelAdmin):
    list_display = ('serNo','make', 'model', 'section_id', 'storage_capacity_tb','no_of_hard_disks', 'purchase_date')
    list_filter = ( 'purchase_date','section_id', 'storage_capacity_tb','no_of_hard_disks')
    search_fields = ('serNo', 'make','model','storage_capacity_tb','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date')      

#-------- Rack Server-----------------------------------------------------------
@admin.register(RackServer)
class RackServerAdmin(admin.ModelAdmin):
    list_display = ('serNo','make', 'model', 'no_of_cpus', 'cpu_details','memory_details','storage_details', 'purchase_date')
    list_filter = ( 'purchase_date','no_of_cpus')
    search_fields = ('serNo', 'make','model','cpu_details','memory_details','storage_details','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date') 


#-------- Blade Server-----------------------------------------------------------
@admin.register(BladeServer)
class BladeServerAdmin(admin.ModelAdmin):
    list_display = ('serNo','make', 'model', 'no_of_blades','no_of_cpus', 'cpu_details','memory_details','storage_details', 'purchase_date')
    list_filter = ( 'purchase_date','no_of_cpus')
    search_fields = ('serNo', 'make','model','cpu_details','memory_details','storage_details','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date') 

#-------- SAN Storage -----------------------------------------------------------
@admin.register(SAN)
class SANAdmin(admin.ModelAdmin):
    list_display = ('serNo','make', 'model', 'no_of_controllers','storage_capacity','description')
    list_filter = ( 'purchase_date','storage_capacity')
    search_fields = ('serNo', 'make','model','storage_capacity','description')
    date_hierarchy = 'purchase_date'
    ordering = ('section_id', 'purchase_date') 