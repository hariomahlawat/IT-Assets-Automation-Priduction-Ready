from collections import Counter
from django import template
from ..models import *

register = template.Library()

# Desktop Custom tags=======================================================
@register.simple_tag
def total_desktops():
    return Desktop.objects.count()

@register.simple_tag
def win7_desktops():
    return DesktopSoftware.objects.filter(os__icontains='7').count()

@register.simple_tag
def win8_desktops():
    return DesktopSoftware.objects.filter(os__icontains='8').count()

@register.simple_tag
def win10_desktops():
    return DesktopSoftware.objects.filter(os__icontains='10').count()

@register.simple_tag
def i3_desktops():
    return Desktop.objects.filter(cpu__icontains='i3').count()

@register.simple_tag
def i5_desktops():
    return Desktop.objects.filter(cpu__icontains='i5').count()

@register.simple_tag
def i7_desktops():
    return Desktop.objects.filter(cpu__icontains='i7').count()

# Laptop Custom tags=======================================================
@register.simple_tag
def total_laptops():
    return Laptop.objects.count()

@register.simple_tag
def win7_laptops():
    return LaptopSoftware.objects.filter(os__icontains='7').count()

@register.simple_tag
def win8_laptops():
    return LaptopSoftware.objects.filter(os__icontains='8').count()

@register.simple_tag
def win10_laptops():
    return LaptopSoftware.objects.filter(os__icontains='10').count()

@register.simple_tag
def i3_laptops():
    return Laptop.objects.filter(cpu__icontains='i3').count()

@register.simple_tag
def i5_laptops():
    return Laptop.objects.filter(cpu__icontains='i5').count()

@register.simple_tag
def i7_laptops():
    return Laptop.objects.filter(cpu__icontains='i7').count()

#==========================================================================
@register.simple_tag
def total_printers():
    return Printer.objects.count()

@register.simple_tag
def total_NAS():
    return NAS.objects.count()  

@register.simple_tag
def total_SAN():
    return SAN.objects.count()  

@register.simple_tag
def total_rack_servers():
    return RackServer.objects.count()

@register.simple_tag
def total_blade_servers():
    return BladeServer.objects.count()

#======== Cutom Inclusion tags for detail page ============================================
@register.inclusion_tag('inventory/desktop_software_detail.html')
def get_desktop_software_details(ser_no):
    desktop_software_details= DesktopSoftware.objects.filter(desktop_id=ser_no)
    return {'desktop_software_details' : desktop_software_details}

@register.inclusion_tag('inventory/laptop_software_detail.html')
def get_laptop_software_details(ser_no):
    laptop_software_details= LaptopSoftware.objects.filter(laptop_id=ser_no)
    return {'laptop_software_details' : laptop_software_details}    

#====== Time Series Chart - Custom Tags ===================================================
#-------- Desktop--------------------------
@register.simple_tag
def desktop_time_series_year():
    desktop = Desktop.objects.values('purchase_date__year',)
    d=[]
    for item in desktop:
        d.append(item['purchase_date__year'])
    x=dict(Counter(d))
    x_keys=x.keys()
    min_year = min(x_keys)
    max_year = max(x_keys)
    final_year_list = list(range(min_year,max_year+1))
    final_data_list=[]
    for item in final_year_list:
        if item in x.keys():
            final_data_list.append(x[item])
        else:
            final_data_list.append(0)   
    return final_year_list

@register.simple_tag
def desktop_time_series_data():
    desktop = Desktop.objects.values('purchase_date__year',)
    d=[]
    for item in desktop:
        d.append(item['purchase_date__year'])
    x=dict(Counter(d))
    x_keys=x.keys()
    min_year = min(x_keys)
    max_year = max(x_keys)
    final_year_list = list(range(min_year,max_year+1))
    final_data_list=[]
    for item in final_year_list:
        if item in x.keys():
            final_data_list.append(x[item])
        else:
            final_data_list.append(0)  
    return final_data_list

#-------- Laptop--------------------------

@register.simple_tag
def laptop_time_series_year():
    laptop = Laptop.objects.values('purchase_date__year',)
    d=[]
    for item in laptop:
        d.append(item['purchase_date__year'])
    x=dict(Counter(d))
    x_keys=x.keys()
    min_year = min(x_keys)
    max_year = max(x_keys)
    final_year_list = list(range(min_year,max_year+1))
    final_data_list=[]
    for item in final_year_list:
        if item in x.keys():
            final_data_list.append(x[item])
        else:
            final_data_list.append(0)   
    return final_year_list

@register.simple_tag
def laptop_time_series_data():
    laptop = Laptop.objects.values('purchase_date__year',)
    d=[]
    for item in laptop:
        d.append(item['purchase_date__year'])
    x=dict(Counter(d))
    x_keys=x.keys()
    min_year = min(x_keys)
    max_year = max(x_keys)
    final_year_list = list(range(min_year,max_year+1))
    final_data_list=[]
    for item in final_year_list:
        if item in x.keys():
            final_data_list.append(x[item])
        else:
            final_data_list.append(0)  
    return final_data_list

#---- Printer ----------------------------------------------------

@register.simple_tag
def printer_time_series_year():
    printer = Printer.objects.values('purchase_date__year',)
    d=[]
    for item in printer:
        d.append(item['purchase_date__year'])
    x=dict(Counter(d))
    x_keys=x.keys()
    min_year = min(x_keys)
    max_year = max(x_keys)
    final_year_list = list(range(min_year,max_year+1))
    final_data_list=[]
    for item in final_year_list:
        if item in x.keys():
            final_data_list.append(x[item])
        else:
            final_data_list.append(0)   
    return final_year_list

@register.simple_tag
def printer_time_series_data():
    printer = Printer.objects.values('purchase_date__year',)
    d=[]
    for item in printer:
        d.append(item['purchase_date__year'])
    x=dict(Counter(d))
    x_keys=x.keys()
    min_year = min(x_keys)
    max_year = max(x_keys)
    final_year_list = list(range(min_year,max_year+1))
    final_data_list=[]
    for item in final_year_list:
        if item in x.keys():
            final_data_list.append(x[item])
        else:
            final_data_list.append(0)  
    return final_data_list