# inventory/views.py
from collections import Counter
from django.http import HttpResponse
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin  # new
from django.views.generic import TemplateView, ListView,DetailView
from .models import Desktop, Section, ITAsset, Laptop, Printer, NAS, SAN, BladeServer, RackServer

        

class DashboardView(TemplateView):
    template_name = 'inventory/dashboard.html'
    context_object_name = 'dashboard'
    model=Desktop
    pass

############### Section Inventory View #################################


class Mo1Inventory(TemplateView):
    template_name = 'inventory/section/mo1.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 1").exclude(name__icontains="mo 10").exclude(name__icontains="mo 11").exclude(name__icontains="mo 12").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo2Inventory(TemplateView):
    template_name = 'inventory/section/mo2.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 2").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo3AInventory(TemplateView):
    template_name = 'inventory/section/mo3a.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 3a").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo3BInventory(TemplateView):
    template_name = 'inventory/section/mo3b.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 3b").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo4Inventory(TemplateView):
    template_name = 'inventory/section/mo4.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 4").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo5Inventory(TemplateView):
    template_name = 'inventory/section/mo5.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 5").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context

class Mo6Inventory(TemplateView):
    template_name = 'inventory/section/mo6.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 6").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context
class Mo7Inventory(TemplateView):
    template_name = 'inventory/section/mo7.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 7").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context
class Mo8AInventory(TemplateView):
    template_name = 'inventory/section/mo8a.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 8a").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo8BInventory(TemplateView):
    template_name = 'inventory/section/mo8b.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 8b").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context
class Mo9Inventory(TemplateView):
    template_name = 'inventory/section/mo9.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 9").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context

class Mo10Inventory(TemplateView):
    template_name='inventory/section/mo10.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(name__icontains="mo 10").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo11Inventory(TemplateView):
    template_name = 'inventory/section/mo11.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 11").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class Mo12Inventory(TemplateView):
    template_name = 'inventory/section/mo12.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="mo 12").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class ServerRoomInventory(TemplateView):
    template_name = 'inventory/section/server_room.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="server room").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class ADPCellInventory(TemplateView):
    template_name = 'inventory/section/adp_cell.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="gis cell").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


class ADPStoreInventory(TemplateView):
    template_name = 'inventory/section/adp_store.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet of all the books
        sec_id = Section.objects.filter(
            name__icontains="adp store").values_list('id', flat="True")
        context['desktop_list'] = Desktop.objects.filter(section_id__in=sec_id)
        context['laptop_list'] = Laptop.objects.filter(section_id__in=sec_id)
        context['printer_list'] = Printer.objects.filter(section_id__in=sec_id)
        context['nas_list'] = NAS.objects.filter(section_id__in=sec_id)
        return context


########## Desktop Views ############################################
class DesktopListView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'desktop_list'
    queryset = Desktop.desktop_list.all().order_by('section_id')
    template_name = 'inventory/desktop_list.html'


class DesktopDetailView(LoginRequiredMixin,  DetailView):
    context_object_name = 'desktop_detail'
    template_name = "inventory/desktop_detail.html"
    model = Desktop

########## Laptop Views ############################################    
class LaptopListView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'laptop_list'
    queryset = Laptop.laptop_list.all().order_by('section_id')
    template_name = 'inventory/laptop_list.html'


class LaptopDetailView(LoginRequiredMixin, DetailView):
    context_object_name = 'laptop_detail'
    template_name = "inventory/laptop_detail.html"
    model = Laptop

########## Printer Views ############################################    


class PrinterListView(LoginRequiredMixin,  ListView):
    paginate_by = 15
    context_object_name = 'printer_list'
    queryset = Printer.printer_list.all().order_by('section_id')
    template_name = 'inventory/printer_list.html'


class PrinterDetailView(LoginRequiredMixin, DetailView):
    context_object_name = 'printer_detail'
    template_name = "inventory/printer_detail.html"
    model = Printer

########## NAS Views ############################################    
class NASListView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'nas_list'
    queryset = NAS.nas_list.all().order_by('section_id')
    template_name = 'inventory/nas_list.html'


class NASDetailView(LoginRequiredMixin, DetailView):
    context_object_name = 'nas_detail'
    template_name = "inventory/nas_detail.html"
    model = NAS

########## SAN Views ############################################    
class SANListView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'san_list'
    queryset = SAN.san_list.all().order_by('section_id')
    template_name = 'inventory/san_list.html'


class SANDetailView(LoginRequiredMixin, DetailView):
    context_object_name = 'san_detail'
    template_name = "inventory/san_detail.html"
    model = SAN

########## Blade Server Views ############################################    
class BladeServerListView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'blade_server_list'
    queryset = BladeServer.blade_server_list.all().order_by('section_id')
    template_name = 'inventory/blade_server_list.html'


class BladeServerDetailView(LoginRequiredMixin, DetailView):
    context_object_name = 'blade_server_detail'
    template_name = "inventory/blade_server_detail.html"
    model = BladeServer

########## Rack Server Views ############################################    
class RackServerListView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'rack_server_list'
    queryset = RackServer.rack_server_list.all().order_by('section_id')
    template_name = 'inventory/rack_server_list.html'


class RackServerDetailView(LoginRequiredMixin, DetailView):
    context_object_name = 'rack_server_detail'
    template_name = "inventory/rack_server_detail.html"
    model = RackServer
