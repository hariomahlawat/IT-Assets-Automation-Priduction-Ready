from django.contrib import admin
from .models import *

# Register your models here.


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('author', 'title', 'due_date', 'assigned_to',
                    'status', 'table')
    list_filter = ('table', 'status', 'assigned_to','author')
    search_fields = ('title', 'remarks')
    date_hierarchy = 'created'
    ordering = ('due_date', 'created')
