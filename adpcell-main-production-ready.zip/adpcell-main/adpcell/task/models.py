import uuid
from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User


class Task(models.Model):
    STATUS_CHOICES = (
        ('under_progress', 'Under Progress'),
        ('out_for_comments', 'Out for Comments'),
        ('completed', 'Completed'),
    )
    TABLE_CHOICES = (
        ('svl', 'SVL'),
        ('comn', 'COMN'),
        ('is', 'Info Sys & SPACE'),
        ('adp', 'ADP & GIS'),
    )
    id = models.UUIDField(  
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    title = models.CharField(max_length=250)
    author = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='tasks')
    table = models.CharField(max_length=30,
                             choices=TABLE_CHOICES,
                             default='draft')
    assigned_to = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, related_name='assigned_tasks', null=True, blank=True)
    remarks = models.TextField()
    created = models.DateField(auto_now_add=True)
    updated = models.DateField(auto_now=True)
    due_date = models.DateField(auto_now=False, auto_now_add=False, null=True, blank=True)
    status = models.CharField(max_length=20,
                              choices=STATUS_CHOICES,
                              default='under_progress')

    class Meta:
        ordering = ('-due_date','created')

    def __str__(self):
        return self.title
    
