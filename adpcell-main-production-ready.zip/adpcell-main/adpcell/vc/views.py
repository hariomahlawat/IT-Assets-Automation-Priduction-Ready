# vc/views.py

from datetime import datetime, timedelta
from collections import Counter
from django.http import HttpResponse
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin  # new
from django.views.generic import ListView, CreateView
from .models import VC


class VCListAllView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'vc_list_all'
    today = datetime.today()+timedelta(hours=-1)
    queryset = VC.vc_list.all()
    template_name = 'vc/vc_list.html'

class VCListUpcomingView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'vc_list_upcoming'
    today = datetime.today()+timedelta(hours=-1)
    queryset = VC.vc_list.all().filter(vc_from__gt=today).order_by('vc_from')
    template_name = 'vc/vc_list_upcoming.html'


class VCListTodayView(LoginRequiredMixin, ListView):
    paginate_by = 15
    context_object_name = 'vc_list_today'
    today = datetime.today()+timedelta(hours=-12)
    tomorrow = today + timedelta(days=1)
    queryset = VC.vc_list.all().filter(vc_from__gt=today).filter(vc_from__lt=tomorrow).order_by('vc_from')
    template_name = 'vc/vc_list_today.html'


