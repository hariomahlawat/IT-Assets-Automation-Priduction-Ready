from django.contrib import admin
from .models import *


#-------- VC Models-----------------------------------------------------------
@admin.register(VC)
class VCAdmin(admin.ModelAdmin):
    list_display = ('vc_from', 'vc_to', 'title', 'location','media','entities','section','remarks')
    list_filter = ('vc_from', 'location', 'media','section')
    search_fields = ('title', 'remarks', 'location','media','entities')
    date_hierarchy = 'vc_from'
    ordering = ('vc_from', 'location')
