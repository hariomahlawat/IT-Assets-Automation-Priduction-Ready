from django.urls import path
from .views import *

app_name = 'vc'

urlpatterns = [

    path('today/', VCListTodayView.as_view(),  name='vc_list_today'),
    path('upcoming/', VCListUpcomingView.as_view(),  name='vc_list_upcoming'),
    path('all/', VCListAllView.as_view(),  name='vc_list'),
]
