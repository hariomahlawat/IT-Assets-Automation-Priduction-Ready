from datetime import datetime, timedelta
from collections import Counter
from django import template
from ..models import *

register = template.Library()


# VC Custom tags=======================================================
@register.simple_tag
def total_vc_upcoming():
    today = datetime.today()
    return VC.objects.all().filter(vc_from__gt=today).count()


@register.simple_tag
def total_vc_today():
    today = datetime.today()+timedelta(hours=-12)
    tomorrow = today + timedelta(days=1)
    return VC.objects.all().filter(vc_from__gt=today).filter(vc_from__lt=tomorrow).count()
