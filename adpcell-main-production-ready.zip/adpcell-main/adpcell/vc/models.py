# vc/models.py
import uuid
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse


class VCListManager(models.Manager):
    def get_queryset(self):
        return super(VCListManager, self).get_queryset()


class VC(models.Model):
    objects = models.Manager()  # The default manager.
    vc_list = VCListManager()  # Our custom manager.
    id = models.UUIDField(  # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    LOCATION_CHOICES = (
        ('moor', 'MOOR'),
        ('sitroom', 'SitRoom'),
    )
    MEDIA_CHOICES = (
        ('adn', 'ADN'),
        ('dcn', 'DCN'),
    )
    vc_from = models.DateTimeField( auto_now=False, auto_now_add=False)
    vc_to = models.DateTimeField( auto_now=False, auto_now_add=False, null=True, blank=True)
    trial_scheduled = models.DateTimeField(auto_now=False, auto_now_add=False, null=True, blank=True)
    title = models.CharField(max_length=100, null=True, blank=True)
    section = models.CharField(max_length=50, null=True, blank=True)
    location = models.CharField( max_length=50, choices=LOCATION_CHOICES, default='MOOR', null=True, blank=True)
    media = models.CharField( max_length=50, choices=MEDIA_CHOICES, default='ADN', null=True, blank=True)
    entities = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.title


