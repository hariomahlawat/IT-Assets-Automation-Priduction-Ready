# users/forms.py
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from .models import CustomUser

class CustomUserCreationForm(UserCreationForm):
    
    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ('username','section','role')


class CustomUserChangeForm(UserChangeForm):
    
    class Meta:
        model = CustomUser
        fields =('username','section','role')
