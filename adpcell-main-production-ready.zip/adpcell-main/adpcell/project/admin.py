from django.contrib import admin
from .models import *

admin.site.register(CodeHead)
admin.site.register(FY)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('it_ppp_ser_no', 'code_head', 'title', 'amount','fy',
                    'status', 'scope')
    list_filter = ('fy', 'code_head')
    search_fields = ('title', 'scope', 'remarks')
    ordering = ('fy', 'code_head')


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('name', 'title', 'project_id', 'created', 'active')
    list_filter = ('active', 'created', 'updated')
    search_fields = ('name', 'title', 'body')
    actions = ['approve_comments']

    def approve_comments(self, request, queryset):
        queryset.update(active=True)
