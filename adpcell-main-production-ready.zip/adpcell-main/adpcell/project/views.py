# project/views.py

from datetime import datetime, timedelta
from collections import Counter
from functools import wraps

from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponse
from django.contrib.auth import authenticate
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin  # new
from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView, DetailView

from .models import Project, Comment
from .forms import CommentForm


class ProjectListView(LoginRequiredMixin, ListView):
    context_object_name = 'project_list'
    queryset = Project.project_list.all().order_by('code_head')
    template_name = 'project/project_list.html'


class ProjectListOngoingView(LoginRequiredMixin, ListView):
    context_object_name = 'project_list_ongoing'
    queryset = Project.project_list.exclude(status__contains="bill_passed").order_by('code_head')
    template_name = 'project/project_list_ongoing.html'


class ProjectListCompletedView(LoginRequiredMixin, ListView):
    context_object_name = 'project_list_completed'
    queryset = Project.project_list.filter(status__contains="bill_passed").order_by('code_head')
    template_name = 'project/project_list_completed.html'


# @user_passes_test(lambda u: u.is_superuser)
@user_passes_test(lambda u: u.is_active)
def project_detail(request, pk):
    template_name = 'project/project_detail.html'
    project_id = get_object_or_404(Project, pk=pk)
    comments = project_id.comments.filter(active=True)
    new_comment = None

    # Comment posted
    if request.method == 'POST':
        comment_form = CommentForm(data=request.POST)
        if comment_form.is_valid():

            # Create Comment object but don't save to database yet
            new_comment = comment_form.save(commit=False)
            # Assign the current post to the comment
            new_comment.project_id = project_id
            # Save the comment to the database
            new_comment.save()
        
    else:
        comment_form = CommentForm()

    return render(request, template_name, {'project_detail': project_id,
                                               'comments': comments,
                                               'new_comment': new_comment,
                                               'comment_form': comment_form})




