# project/models.py
import uuid
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse


class CodeHead(models.Model):
    code_head = models.CharField( max_length=50)
    category = models.CharField( max_length=50)

    def __str__(self):
        return self.code_head

class FY(models.Model):
    fy = models.CharField( max_length=50)

    def __str__(self):
        return self.fy


class ProjectListManager(models.Manager):
    def get_queryset(self):
        return super(ProjectListManager, self).get_queryset()

class Project(models.Model):
    objects = models.Manager()  # The default manager.
    project_list = ProjectListManager()  # Our custom manager.
    STATUS_CHOICES = (
        ('ipa', 'IPA'),
        ('ifa_concurrence_aon', 'IFACocurrenceAoN'),
        ('aon', 'AoN'),
        ('bidding_tec', 'BiddingTEC'),
        ('bidding_commercial', 'BiddingCommercial'),
        ('ifa_concurrence_uon_no', 'IFACocurrenceUonNo'),
        ('cfa_sanction', 'CFASanction'),
        ('so', 'SO'),
        ('atp_board', 'ATPBoard'),
        ('bill_submitted', 'BillSubmitted'),
        ('bill_passed', 'BillPassed'),
    )
    PROJECT_TYPE_CHOICES=(
        ('new', 'New'),
        ('cl', 'CL'),
        ('cf','CF')
    )
    id = models.UUIDField(  # new
        primary_key=True,
        default=uuid.uuid4,
        editable=False)
    title = models.CharField( max_length=200)
    code_head = models.ForeignKey("project.CodeHead", on_delete=models.CASCADE, related_name='all_projects')
    fy = models.ForeignKey("project.FY", on_delete=models.CASCADE, related_name='all_projects')
    it_ppp_ser_no = models.CharField(max_length=100, null=True, blank=True)
    project_type = models.CharField(max_length=50, choices=PROJECT_TYPE_CHOICES, default='NEW', null=True, blank=True)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default='IPA', null=True, blank=True)
    amount = models.CharField( max_length=50, null=True, blank=True)
    cash_outgo = models.CharField( max_length=50, null=True, blank=True)
    scope = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)

    class Meta:
        ordering = ('code_head',)
    
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('project_detail', args=[str(self.id)])


class Comment(models.Model):
    project_id = models.ForeignKey(Project, on_delete=models.CASCADE,  related_name='comments')
    name = models.CharField(max_length=80)
    title = models.CharField(max_length=80)
    body = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=False)
    
    class Meta:
        ordering = ('created',)
        
    def __str__(self):
        return f'Comment by {self.name} on {self.project_id}'
