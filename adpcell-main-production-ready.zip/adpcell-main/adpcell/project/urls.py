from django.urls import path
from . import views
from .views import ProjectListView,  ProjectListOngoingView, ProjectListCompletedView

app_name = 'project'

urlpatterns = [

    path('all/', ProjectListView.as_view(),  name='project_list'),
    path('ongoing/', ProjectListOngoingView.as_view(),  name='project_list_ongoing'),
    path('completed/', ProjectListCompletedView.as_view(),  name='project_list_completed'),
    path('<uuid:pk>/', views.project_detail,  name='project_detail'),

]
