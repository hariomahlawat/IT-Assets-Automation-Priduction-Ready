from django import template
from ..models import Project

register = template.Library()


@register.simple_tag
def total_projects():
    return Project.objects.all().count()


@register.simple_tag
def total_projects_completed():
    return Project.objects.filter(status__contains="bill_passed").count()


@register.simple_tag
def total_projects_ongoing():
    return Project.objects.exclude(status__contains="bill_passed").count()


@register.simple_tag
def tota_projects_ipa():
    return Project.objects.filter(status__contains="ipa").count()


@register.simple_tag
def tota_projects_ifa_concurrence_aon():
    return Project.objects.filter(status__contains="ifa_concurrence_aon").count()


@register.simple_tag
def tota_projects_aon():
    return Project.objects.filter(status__contains="aon").count()


@register.simple_tag
def tota_projects_bidding_tec():
    return Project.objects.filter(status__contains="bidding_tec").count()


@register.simple_tag
def tota_projects_bidding_commercial():
    return Project.objects.filter(status__contains="bidding_commercial").count()


@register.simple_tag
def tota_projects_ifa_concurrence_uon_no():
    return Project.objects.filter(status__contains="ifa_concurrence_uon_no").count()


@register.simple_tag
def tota_projects_cfa_sanction():
    return Project.objects.filter(status__contains="cfa_sanction").count()


@register.simple_tag
def tota_projects_so():
    return Project.objects.filter(status__contains="so").count()


@register.simple_tag
def tota_projects_atp_board():
    return Project.objects.filter(status__contains="atp_board").count()


@register.simple_tag
def tota_projects_bill_submitted():
    return Project.objects.filter(status__contains="bill_submitted").count()


@register.simple_tag
def tota_projects_bill_passed():
    return Project.objects.filter(status__contains="bill_passed").count()
